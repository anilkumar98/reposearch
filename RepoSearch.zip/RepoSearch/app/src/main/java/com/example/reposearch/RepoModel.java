package com.example.reposearch;

public class RepoModel implements Comparable<RepoModel>{
    private String name;
    private String url;
    private String description;
    private String star;

    public  void setName(String name1)
    {
        name = name1;
    }
    public void setUrl(String url1)
    {
        url=url1;
    }
    public void setDescription(String desc)
    {
        description=desc;
    }
    public void setStar(String star1)
    {
        star=star1;
    }
    public String getName()
    {
        return name;
    }
    public String getUrl()
    {
        return url;
    }
    public String getDescription()
    {
        return description;
    }
    public String getStar()
    {
        return star;
    }

    @Override
    public int compareTo(RepoModel another) {
        return Integer.parseInt(getStar()) > Integer.parseInt(another.getStar())?-1:1;
    }
}
