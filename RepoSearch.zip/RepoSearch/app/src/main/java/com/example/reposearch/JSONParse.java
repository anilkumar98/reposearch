package com.example.reposearch;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class JSONParse {
    private String[] names;
    private String[] urls;
    private String[] desc;
    private String[] star;
    private JSONArray repoArray = null;
    List<RepoModel> repoModelList ;
    JSONObject jsnobject;
    private String json;

    public  JSONParse(String json){
        
        this.json = json;
    }

    public void JSONParse(){
        try {

            try {

                 jsnobject = new JSONObject(json);
                 repoArray = jsnobject.getJSONArray("items");
                } catch (JSONException e) {
                  e.printStackTrace();
            }

            if(jsnobject != null) {
                names = new String[repoArray.length()];
                urls = new String[repoArray.length()];
                desc = new String[repoArray.length()];
                star = new String[repoArray.length()];
                repoModelList = new ArrayList<RepoModel>();

            for(int i=0;i< repoArray.length();i++) {
                RepoModel repoModel_object = new RepoModel();

                JSONObject jsonObject = repoArray.getJSONObject(i);

                names[i] = jsonObject.getString("full_name");
                desc[i] = jsonObject.getString("description");
                star[i] = jsonObject.getString("stargazers_count");
                JSONObject ownerObject = jsonObject.getJSONObject("owner");
                urls[i] = ownerObject.getString("avatar_url");

                repoModel_object.setName(names[i]);
                repoModel_object.setUrl(urls[i]);
                repoModel_object.setDescription(desc[i]);
                repoModel_object.setStar(star[i]);
                repoModelList.add(repoModel_object);
                Collections.sort(repoModelList );
            }
          }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    List<RepoModel> getRepos()
    {
        return repoModelList;
    }
}
