package com.example.reposearch;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import com.bumptech.glide.Glide;
import java.util.List;

public class RepoAdapter extends RecyclerView.Adapter<RepoAdapter.ViewHolder> {
    private List<RepoModel> mDataset;

    public class ViewHolder extends RecyclerView.ViewHolder {
        private TextView name;
        private TextView desc;
        private TextView star;
        private ImageView imageView;

        public ViewHolder(View v) {
            super(v);
            name = (TextView) v.findViewById(R.id.name);
            desc = (TextView) v.findViewById(R.id.description);
            star = (TextView) v.findViewById(R.id.star) ;
            imageView = (ImageView) v.findViewById(R.id.avatar);
        }
    }

    public RepoAdapter(List<RepoModel> myDataset) {
        mDataset = myDataset;
    }

    @Override
    public RepoAdapter.ViewHolder onCreateViewHolder(ViewGroup parent,
                                                     int viewType) {
        // create a new view
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.repo_item, parent, false);
        ViewHolder vh = new ViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {

        if(mDataset != null) {
            holder.name.setText(mDataset.get(position).getName());
            holder.desc.setText(mDataset.get(position).getDescription());
            holder.star.setText(mDataset.get(position).getStar() + "  " + "\u2605");
        }
        Glide.with(holder.imageView.getContext()).load(mDataset.get(position).getUrl()).placeholder(R.drawable.ic_launcher_foreground).dontAnimate().into(holder.imageView);
    }
    @Override
    public int getItemCount() {
        if(mDataset != null)
         return mDataset.size();
        else
         return 0;
    }
}