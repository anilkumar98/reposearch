package com.example.reposearch;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import com.android.volley.RequestQueue;
import java.util.List;


public class MainRepoSearchActivity extends AppCompatActivity {
    public static final String URL = "https://api.github.com/search/repositories?q=/";

    private TextView mTextView;
    private EditText inputQuery;
    private Button mButton;
    private RequestQueue mQueue;
    private RecyclerView mRecyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager mLayoutManager;
    List<RepoModel> mDataset;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_repo_search);
        inputQuery = (EditText) findViewById(R.id.inputQuery);
        mButton = (Button) findViewById(R.id.searchbutton);
    }

    @Override
    protected void onStart() {
        super.onStart();
        mButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String query = inputQuery.getText().toString();
                Intent myIntent = new Intent(MainRepoSearchActivity.this, RecyclerViewActivity.class);
                myIntent.putExtra("url", URL+query);
                MainRepoSearchActivity.this.startActivity(myIntent);
            }
        });
    }

    @Override
    protected void onStop() {
        super.onStop();
    }
}

